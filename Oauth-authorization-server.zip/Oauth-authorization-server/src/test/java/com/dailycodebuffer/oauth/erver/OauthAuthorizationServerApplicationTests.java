package com.dailycodebuffer.oauth.erver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthAuthorizationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
