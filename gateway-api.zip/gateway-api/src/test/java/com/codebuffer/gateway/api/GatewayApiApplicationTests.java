package com.codebuffer.gateway.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
